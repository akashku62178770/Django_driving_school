from django.shortcuts import render, redirect
from .forms import NewUserForm, NotificationsForm, BookingForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm

from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.models import User
from django.template.loader import render_to_string
from django.db.models.query_utils import Q
from django.utils.http import urlsafe_base64_encode
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes
from django.contrib import messages
from .models import Schools, Contact, Rating, Booking, Notifications
import googlemaps
import json
from django.conf import settings
import graphql_jwt
import folium
import geocoder

# Create your views here.


def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            print(user)
            login(request, user, backend='graphql_jwt.backends.JSONWebTokenBackend')
            messages.success(request, "Registration successful.")
            return redirect("homepage")
        messages.error(
            request, "Unsuccessful registration. Invalid information.")
    else:
        form = NewUserForm()
    return render(request, "school/register.html", context={"register_form": form})


def login_request(request):
    thank = False
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            thank = True
            if user is not None:
                # user.backend = 'django.contrib.auth.backends.ModelBackend'
                login(request, user,
                      backend='graphql_jwt.backends.JSONWebTokenBackend')
                messages.info(request, f"You are now logged in as {username}.")
                return redirect("homepage")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = AuthenticationForm()
    return render(request, "school/login.html", {"login_form": form, "thank": thank})


def logout_request(request):
    logout(request)
    messages.info(request, "You have successfully logged out.")
    return redirect("homepage")


def password_reset_request(request):
    if request.method == "POST":
        password_reset_form = PasswordResetForm(request.POST)
        if password_reset_form.is_valid():
            data = password_reset_form.cleaned_data['email']
            associated_users = User.objects.filter(Q(email=data))
            if associated_users.exists():
                for user in associated_users:
                    subject = "Password Reset Requested"
                    email_template_name = "school/password/password_reset_email.txt"
                    c = {
                        "email": user.email,
                        'domain': '127.0.0.1:8000',
                        'site_name': 'Website',
                        "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                        'token': default_token_generator.make_token(user),
                        'protocol': 'http',
                    }
                    email = render_to_string(email_template_name, c)
                    try:
                        send_mail(subject, email, 'admin@example.com',
                                  [user.email], fail_silently=False)
                    except BadHeaderError:

                        return HttpResponse('Invalid header found.')

                    messages.success(
                        request, 'A message with reset password instructions has been sent to your inbox.')
                    return redirect("homepage")
            messages.error(request, 'An invalid email has been entered.')
    password_reset_form = PasswordResetForm()
    return render(request, "school/password/password_reset.html", context={"password_reset_form": password_reset_form})


def homepage(request):
    return render(request, "school/homepage.html")


def customer(request):
    thank = False
    form = CustomerForm()
    if request.method == "POST":
        form = CustomerForm(request.POST)
        if form.is_valid():
            # print("customer", request.POST)
            obj = form.save(commit=False)
            obj.user = request.user
            obj.email = request.user.email
            obj.save()
            thank = True
            return redirect("homepage")

    return render(request, "school/customer.html", {'form': form, 'thank': thank})


def customer_update(request):
    # obj = Staff.objects.filter(pk=self.kwargs['staff_id']).first()
    # obj = Customer.objects.filter(pk=kwargs['staff_id']).first()
    thank = False
    user = request.user
    customer = Customer.objects.filter(user=user)
    form = CustomerForm(instance=customer)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.id = request.user.id
        obj.save()
        thank = True
        return redirect("homepage")

    return render(request, "school/customer_update.html", {'form': form, 'thank': thank})


def profile(request):
    msg = False
    user = request.user
    print(user)
    profile = Customer.objects.filter(user=user)[0]
    print(profile)
    return render(request, "school/profile.html", {'profile': profile})
    #  email=user.email)
    # try:
    #     profile = Customer.objects.filter(user=user)
    # except:
    #     msg = True
    #     redirect("customer", {"msg": msg})
    # msg = True
    # if not profile.exists():
    #     redirect("customer")
    #     msg = True
    # if Customer.objects.filter(user=user).exists():
    #     profile = Customer.objects.filter(user=user)
    #     print("name", profile.name)
    #

    # else:
    #     msg = True
    #     return redirect("customer")

    # print(profile)


def schools(request):
    schools = Schools.objects.all()
    rating = Rating.objects.all()
    return render(request, "school/schools.html", {'schools': schools, 'rating': rating})


def schoolDetails(request, myid):
    school = Schools.objects.filter(id=myid)
    rating = Rating.objects.filter(id=myid) 
    print(school[0].address)
    address = school[0].address
    location = geocoder.osm(address)
    lat = location.lat
    lng = location.lng
    print(lat, lng)
    country = location.country
    if lat == None or lng == None:
        lat = 19.0116962
        lng = 72.8180702
        # address.delete()
        # return HttpResponse('You address input is invalid')
    # Create Map Object
    m = folium.Map(location=[19, -12], zoom_start=2)

    folium.Marker([lat, lng], tooltip='Click for more',
                  popup=country).add_to(m)
    # Get HTML Representation of Map Object
    m = m._repr_html_()
    return render(request, "school/schoolDetails.html", {'school': school[0], "m": m, 'rating': rating[0]})


def geocode(request):
    gmaps = googlemaps.Client(key=settings.GOOGLE_API_KEY)
    result = json.dumps(gmaps.geocode(str('Stadionstraat 5, 4815 NC Breda')))
    result2 = json.loads(result)
    adressComponents = result2[0]['geometry']

    context = {
        'result': result,
        'adressComponents': adressComponents
    }
    return render(request, 'school/geocode.html', context)


def message_list(request):
    form = NotificationsForm()

    if request.method == "POST":
        print("msg", request.POST)
        # form = MessagesForm(request.POST)
        if form.is_valid():
            obj = form.save()
        #     obj.id = request.user.id
        #     obj.save()
            return redirect("homepage")
    return render(request, "school/messages.html", {'form': form})


def notifications(request):
    messages = Notifications.objects.all()

    # print(messages[3].school.id)
    # school = (messages[ ].school.id)
    # school = Schools.objects.all()
    return render(request, "school/notifications.html", {'messages': messages})


def booking(request):
    thank = False
    user = request.user
    form = BookingForm()
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.user = user
            obj.items_json = request.COOKIES['cart']
            # cart = json.loads(request.COOKIES['cart'])
            obj.amount = request.COOKIES['price']
            # cart = request.COOKIES.get['cart']
            # print("cart", cart)
            cart = request.COOKIES['cart']
            # print(cart[price])
            print("amount", obj.amount)
            print("item", obj.items_json)
            obj.save()
            thank = True
            return redirect("payment")
    return render(request, "school/booking.html", {'form': form, 'thank': thank})


def about(request):
    return render(request, 'school/about.html')


def payment(request):

    return render(request, 'school/payment.html')


def contact(request):
    thank = False
    if request.method == "POST":
        print("token", request.POST)
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        subject = request.POST.get('subject', '')
        description = request.POST.get('description', '')
        contact = Contact(name=name, email=email, phone=phone,
                          subject=subject, description=description)
        contact.save()
        thank = True
    return render(request, 'school/contact.html', {'thank': thank})
