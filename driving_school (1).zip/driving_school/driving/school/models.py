from django.db import models
from django.contrib.auth.models import User
# Create your models here.
from django.utils import timezone
# from django.contrib.gis.db.models import PointField
from django.core.validators import MaxValueValidator, MinValueValidator


# date = models.DateTimeField(default=timezone.now)


class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    subject = models.CharField(max_length=110, blank=True)
    description = models.TextField(max_length=440)

    def __str__(self):
        return self.name


# class Customer(models.Model):
#     user = models.OneToOneField(User, blank=True, on_delete=models.CASCADE)
#     id = models.AutoField(primary_key=True)
#     name = models.CharField(max_length=100)
#     email = models.EmailField()
#     phone = models.CharField(max_length=20)
#     gender = models.CharField(max_length=1)
#     dob = models.DateField(default=timezone.now)
#     address = models.CharField(max_length=100)
#     city = models.CharField(max_length=100)
#     state = models.CharField(max_length=100)
#     country = models.CharField(max_length=15)

#     def __str__(self):
#         return self.name


timeSlots = (
    ("1", "7:00-8:00"),
    ("2", "8:00-9:00"),
    ("3", "9:00-10:00"),
    ("4", "15:00-16:00"),
    ("5", "16:00-17:00"),
    ("6", "17:00-18:00"),

)


class Booking(models.Model):
    # id = models.AutoField(primary_key=True)
    user = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.CASCADE)
    items_json = models.CharField(max_length=5000)
    amount = models.IntegerField(default=0)
    phone = models.CharField(max_length=12, default="")
    address = models.CharField(max_length=112, default="")
    city = models.CharField(max_length=12, default="")
    state = models.CharField(max_length=12, default="")
    # customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    # coupon = models.IntegerField(null=True, blank=True, help_text="In %")
    zip_code = models.CharField(max_length=111, default="")
    timeSlot = models.CharField(
        max_length=1, choices=timeSlots, null=True, blank=True)

    def __str__(self):
        return str(self.user)

    @property
    def get_total(self):
        gst = .18
        if self.coupon == "HARSH" or self.coupon == "HETAL":
            discount = .1
        else:
            discount = 0
        return self.amount * (1 - discount) * (1 - gst)


class Schools(models.Model):
    name = models.CharField(max_length=100)
    price = models.IntegerField()
    description = models.TextField(max_length=440)
    duration = models.IntegerField(default=2, help_text="In Weeks")
    location = models.CharField(
        max_length=150, help_text="Location", default="Chembur")
    image = models.ImageField(null=True, blank=True, default="")
    address = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url


class Rating(models.Model):
    school = models.OneToOneField(
        Schools, null=True, blank=True, on_delete=models.CASCADE)
    instructor_rating = models.IntegerField(null=True, blank=True, default=1, validators=[
        MaxValueValidator(10),
        MinValueValidator(1)])
    overall_experience = models.IntegerField(null=True, blank=True, default=1, validators=[
        MaxValueValidator(10),
        MinValueValidator(1)])
    comments = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return str(self.comments)


class Notifications(models.Model):
    school = models.ForeignKey(
        Schools, null=True, blank=True, on_delete=models.CASCADE)
    time = models.TimeField(default=timezone.now)
    title = models.CharField(max_length=51, blank=True,
                             help_text="Title of the Notification")
    msg = models.TextField(max_length=151, blank=True, help_text="Message")

    def __str__(self) -> str:
        return str({self.school} - {self.title})


# class Location(models.Model):
#     name = models.CharField(max_length=100)
#     location = models.PointField()
#     address = models.CharField(max_length=100)
#     city = models.CharField(max_length=50)

#     def __str__(self):
#         return self.name
