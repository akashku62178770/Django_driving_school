from django.urls import path, include
from .views import *
# from google import views as view 

urlpatterns = [
    path("", homepage, name="homepage"),
    path("register/", register_request, name="register"),
    path("login/", login_request, name="login"),
    path("logout/", logout_request, name="logout"),
    path("social-auth/", include("social_django.urls", namespace="social")),
    path("password_reset/", password_reset_request, name="password_reset"),
    # path("customer_update/<int:id>", customer_update, name="customer_update"),
    path("customer_update/", customer_update, name="customer_update"),
    path("schools/", schools, name="schools"),
    path("booking/", booking, name="booking"),
    path("about/", about, name="about"),
    path("contact/", contact, name="contact"),
    path("messages/", message_list, name="messages"),
    path("payment/", payment, name="payment"),
    path("notifications/", notifications, name="notifications"),
    path("schoolDetails/<int:myid>", schoolDetails, name="schoolDetails"),
    path("geocode",  geocode, name="geocode"),
]
